package com.ssafy.happyhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PjtDaejeon7thClass6SpringTeam10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
